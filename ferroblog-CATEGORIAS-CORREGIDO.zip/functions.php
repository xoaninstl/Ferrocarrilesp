<?php
// Cargar estilos y scripts
add_action('wp_enqueue_scripts', function () {
    // Cargar Google Fonts
    wp_enqueue_style('google-roboto', 'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap', [], null);
    
    // Cargar la hoja de estilos principal (style.css) correctamente
    wp_enqueue_style('ferroblog-style', get_stylesheet_uri());
    
    // Cargar el script principal (script.js)
    wp_enqueue_script('ferroblog-script', get_template_directory_uri() . '/script.js', [], '1.0', true);
});

// Soportes del tema
add_action('after_setup_theme', function () {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo', [
        'height'      => 120,
        'width'       => 180,
        'flex-width'  => true,
        'flex-height' => true,
    ]);
    register_nav_menus([
        'primary' => __('Menú principal', 'ferroblog'),
        'sidebar' => __('Menú de la barra lateral', 'ferroblog'), // Menú para enlaces rápidos
        'footer'  => __('Menú pie', 'ferroblog'),
    ]);
});

// Función para crear categorías base
function ferroblog_create_categories() {
    $categories = [
        // Noticias
        'metro', 'tram', 'ave', 'cercanias', 'apertura_linea', 'inicio_obras', 'fin_obras', 'evento_especial', 'mantenimiento', 'aniversario',
        // Histórico / líneas
        'ancho_iberico', 'ancho_metrico', 'ancho_internacional', 'lineas_cerradas', 'proyectos_cancelados', 'proyectos_actuales', 'proyectos_en_marcha', 'proyectos_estudio',
        // Ciudades principales de España
        'sevilla', 'madrid', 'barcelona', 'valencia', 'bilbao', 'a_coruna',
        'zaragoza', 'malaga', 'murcia', 'palma', 'las_palmas', 'granada',
        'alicante', 'cordoba', 'valladolid', 'vigo', 'gijon', 'hospitalet',
        'vitoria', 'coruna', 'elche', 'santa_cruz', 'oviedo', 'santander',
        'pamplona', 'castellon', 'almeria', 'burgos', 'salamanca', 'alcorcon',
        'getafe', 'jerez', 'san_sebastian', 'leganes', 'cartagena', 'badalona',
        'leon', 'cadiz', 'tarragona', 'mataro', 'santa_coloma', 'jaen',
        'ourense', 'reus', 'torrelavega', 'el_puerto', 'lugo', 'ceuta',
        'melilla', 'guadalajara', 'pontevedra', 'ferrol', 'aviles', 'gandia'
    ];
    
    foreach ($categories as $slug) {
        if (!term_exists($slug, 'category')) {
            wp_insert_term(ucwords(str_replace('_', ' ', $slug)), 'category', ['slug' => $slug]);
        }
    }
}

// Crear categorías base al activar el tema
add_action('after_switch_theme', 'ferroblog_create_categories');

// También crear categorías en init para asegurar que se creen
add_action('init', function() {
    // Solo crear si no hay categorías personalizadas
    $categories_count = wp_count_terms('category', ['hide_empty' => false]);
    if ($categories_count < 10) { // Si hay menos de 10 categorías, crear las nuestras
        ferroblog_create_categories();
    }
});

/**
 * Modifica la consulta principal de WordPress para aplicar los filtros de categoría del sidebar.
 * Se activa antes de que se ejecute la consulta principal en páginas de archivo (como categorías).
 */
function ferroblog_filter_posts($query) {
    // Solo actuar en la consulta principal del frontend y en páginas de archivo/categoría
    if ( !is_admin() && $query->is_main_query() && ( is_category() || is_archive() ) ) {
        
        // Comprobar si se han enviado filtros desde el formulario
        if (isset($_GET['filter_categories']) && is_array($_GET['filter_categories'])) {
            
            $selected_categories = array_map('sanitize_text_field', $_GET['filter_categories']);

            // 'tax_query' permite consultas complejas basadas en taxonomías (como las categorías)
            $tax_query = [
                'relation' => 'AND', // Exigir que una entrada pertenezca a TODAS las categorías seleccionadas
            ];

            // Añadir cada categoría seleccionada a la consulta
            foreach ($selected_categories as $category_slug) {
                $tax_query[] = [
                    'taxonomy' => 'category',
                    'field'    => 'slug',
                    'terms'    => $category_slug,
                ];
            }
            
            $query->set('tax_query', $tax_query);
        }
    }
}
add_action('pre_get_posts', 'ferroblog_filter_posts');

// Función para forzar la creación de categorías (útil para debugging)
function ferroblog_force_create_categories() {
    if (isset($_GET['create_categories']) && $_GET['create_categories'] === 'ferroblog') {
        ferroblog_create_categories();
        wp_redirect(admin_url('edit-tags.php?taxonomy=category'));
        exit;
    }
}
add_action('init', 'ferroblog_force_create_categories');
?>
